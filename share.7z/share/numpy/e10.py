# Array Slicing

import numpy as np

a = np.arange(10)
print(a)
print('\n')

s = slice(2,7,1)  # 2 to 7-1, step of 1
print(a[s])
print('\n')


import pickle

rawdata = {1:'Indigo',2:'Spice',3:'Jet'}
print(rawdata); print(type(rawdata))

file_Name = "pick4"
fileObjectw = open(file_Name,'wb') 
pickle.dump(rawdata,fileObjectw)   # this writes the object rawdata to the file
fileObjectw.close()                        # here we close the fileObject

fileObjectr = open(file_Name,'r')    # we open the file for reading
myobj = pickle.load(fileObjectr)    # load the object from the file into a variable 

print(myobj); print(type(myobj))
print(rawdata==myobj)
fileObjectr.close()   

from abc import ABC, abstractmethod

class Animal(ABC): 
 
        @abstractmethod
        def say_something(self): 
                print("Hello")

a = Animal()

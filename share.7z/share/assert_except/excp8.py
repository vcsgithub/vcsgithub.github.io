# raise user defined exception
class UserException(Exception):
        #   Base class for other exceptions
        pass

class ValueTooSmallError(UserException):
        def __init__(self, mesg):
                self.mesg = mesg

if __name__ == "__main__":
    try:
        num = int(input("Enter a number: "))
        if num < 11:
            raise ValueTooSmallError("Small Number")
    except ValueTooSmallError as exobj:
        print("This value is too small xx", exobj.mesg)
        print(type(exobj))

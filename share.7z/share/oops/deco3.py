def greet(name):

        def greet_message():
                return "Hello "
        
        print("test 3")
        result = greet_message() + name
        return result

print("test 4")
greet_someone = greet
print("test 5")
greetstr = greet_someone("Python")
print(greetstr)

from abc import abstractmethod,ABC

class Animal(ABC): 
        @abstractmethod
        def say_something(self): 
                print("Hello")

        def fn1(self):
                print("fn1")
#a = Animal()

class Cat(Animal):
        pass
        
        def say_something(self): 
                super().say_something()
                print("World")
  
a = Cat()
a.say_something()
a.fn1()


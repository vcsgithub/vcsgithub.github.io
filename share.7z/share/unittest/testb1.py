import unittest

def   addition(a,b):
    d = a + b
    return d

def   multiplication(a,b):
    d = a * b
    return d

class MyTest1(unittest.TestCase):
    def testMethod1(self):
        self.assertEqual(1 + 2, 3, "1 + 2 not equal to 3")

class MyTest1a(unittest.TestCase):
    def testMethod1a(self):
        self.assertEqual(multiplication(4,-5),-20)
        self.assertEqual(addition(4,-5),-1, "Error")
        self.assertEqual(2 * 3, 6, "2 * 3 not equal to 6")

if __name__ == '__main__':
    unittest.main()

#$ python -m unittest testb1  -> from command line
import   sqlite3    as sql

conn = sql.connect("players2.db");       curs = conn.cursor()

curs.execute("DROP TABLE IF EXISTS Playerstb2")
curs.execute("CREATE TABLE Playerstb2(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR(25), Age         INT, Game     TEXT)")
curs.execute("INSERT INTO Playerstb2(Name,Age,Game) VALUES('Vishy Anand',45,'Chess')")
curs.execute("INSERT INTO Playerstb2(Name,Game) VALUES('PT Usha','Athletics')")
curs.execute("COMMIT")
curs.close()

conn = sql.connect("players2.db");       curs = conn.cursor()
curs.execute("SELECT * FROM Playerstb2");     rows = curs.fetchall()
for row in rows:
        print(row)
import subprocess

cmdcall = "ssh 192.168.27.1 -p 2222 uname -a"
p = subprocess.Popen(cmdcall,shell=True,stderr=subprocess.PIPE,stdout=subprocess.PIPE)
print (p.communicate())

cmdcall = "ssh root@192.168.27.1 -p 2222 sh mysh.sh"
p = subprocess.Popen(cmdcall,shell=True,stderr=subprocess.PIPE,stdout=subprocess.PIPE)

print (p.communicate())

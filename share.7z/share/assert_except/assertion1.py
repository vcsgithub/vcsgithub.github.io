def asrt1(x, y):
        assert y < 25
        assert x < y, "x has to be smaller than y"
        assert (y - x) > 15, "diff is just: " + str(y-x)

        return x+y

print(asrt1(3, 19))          # 23,29  23,19  13,19   3,19

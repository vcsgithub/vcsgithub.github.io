class First(object):
    myprint = lambda self : print("First")
    pass
class Second(First):
    myprint = lambda self : print("Second")
    pass
class Third(First):
    myprint = lambda self : print("Third")
    pass

class Fourth(Second, Third):
    myprint = lambda self : print("Fourth")
    pass

t = Fourth();   t.myprint()



#New-style classes follow a different algorithm that's a bit more complicated to explain, 
#but does the right thing in this situation. 
#(Note that Python 2.3 changes this algorithm to one that 
#produces the same results in most cases, but produces more 
#useful results for really complicated inheritance graphs.)

#List all the base classes, following the classic lookup rule and include 
#a class multiple times if it's visited repeatedly. In the above example, 
#he list of visited classes is [D, B, A, C, A].
#Scan the list for duplicated classes. If any are found, remove all 
#but one occurrence, leaving the last one in the list. 
#In the above example, the list becomes [D, B, C, A] after dropping duplicates.
#Python Excel Create and Save files:

import openpyxl

mywb = openpyxl.Workbook()
print(mywb.get_sheet_names())

sheet = mywb.active
print(sheet.title)
sheet.title = 'MyNewTitle'

print(mywb.get_sheet_names())

mywb.save('NewExcelFile.xlsx')
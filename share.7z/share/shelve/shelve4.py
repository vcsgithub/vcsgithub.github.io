import shelve 

s = shelve.open("myshelf.dat",writeback=True) 
key1 = raw_input("Enter the key\n") 

val1 = int(raw_input("Enter the number of values ")) 

for x in range(val1):
   val = raw_input("\n Enter the value\t") 
   (s[key1]).append(val) 

print s[key1] 
s.sync() 
s.close()
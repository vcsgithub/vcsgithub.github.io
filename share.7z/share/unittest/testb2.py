import unittest

print("modname", __name__)
class MyTest2(unittest.TestCase):

    def testMethod2(self):
        self.assertEqual(1 + 2, 3, "1 + 2 not equal to 3")


if __name__ == '__main__':
    print("testb2 call direct")
    unittest.main()
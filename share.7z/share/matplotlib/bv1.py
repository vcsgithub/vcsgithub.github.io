import matplotlib.pyplot as plt

y = [3, 10, 7, 5, 3, 4.5, 6, 8.1]
N = len(y)
x = range(N)
bar_width = 0.9
plt.bar(x, y, bar_width, color="red",label="Example one")


plt.legend()
plt.xlabel('bar number')
plt.ylabel('bar height')

plt.title('Bar Graph \n Great..')

plt.show()
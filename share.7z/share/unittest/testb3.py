import unittest

class MyTest3(unittest.TestCase):

    def testMethod3(self):
        self.assertEqual(1 + 2, 3, "1 + 2 not equal to 3")


if __name__ == '__main__':
    unittest.main()
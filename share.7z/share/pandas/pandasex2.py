#import pandas as pd
import datetime
import pandas as pd
#import pandas.io.data as web
from pandas_datareader import data as web

start = datetime.datetime(2016, 1, 1)
end = datetime.datetime(2017, 7,23)
#end = datetime.date.today()

google = web.DataReader("GOOG", "google", start, end)
print(type(google))

amazon = web.DataReader("AMZN", "google", start, end)
print(type(amazon))
facebook = web.DataReader("FB", "google", start, end)
print(type(facebook))
print(google.head())
print(amazon.head())



df = pd.DataFrame({"GOOG": google["Close"],
                      "AMZN": amazon["Close"],
                      "FB": facebook["Close"]})
#df1 = web.DataReader("BHARTIARTL.NS", "yahoo", start, end)
print(df)
print(df.head())

df.plot(grid = True)

import matplotlib.pyplot as plt
from matplotlib import style

style.use('fivethirtyeight')

#df.plot()
plt.legend()
plt.show()

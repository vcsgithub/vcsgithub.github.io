#Horizontal  Bar Chart Plotting

import matplotlib.pyplot as plt

stock_names = ["GOOG", "APPL", "IBM", "INTC", "CSCO"]
stock_value = [1000,800,600,400,200]

y_pos = [x for x in range(len(stock_names))]

plt.barh(y_pos, stock_value, align = "center", color = "r", alpha=0.5)
plt.yticks(y_pos, stock_names)
plt.xlabel("Price")
plt.title("Stock Prices")

plt.show()

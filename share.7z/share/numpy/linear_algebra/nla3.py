# Linear Algebra
# solving linear equations  inverse of a matrix

import numpy as np

a = np.array([[1,1,1],[2,1,2],[2,2,1]])
print(a)
print('\n')

b =np.linalg.inv(a)
print(b)
print('\n')

print(np.dot(a,b));  



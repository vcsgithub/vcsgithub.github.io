import unittest

class MyTest(unittest.TestCase):

    def testMethod0(self):          # must start with test
        self.assertEqual(1 + 2, 3, "1 + 2 not equal to 3")

    def testMethod0a(self):          # must start with test
        self.assertEqual(6 - 2, 4, "5 - 2 not equal to 3")

if __name__ == '__main__':
    unittest.main()

# displays on the console
# '.'  means Pass
# 'F' means Fail, assertion will be displayed.
# 'E' means Error other than assertion.
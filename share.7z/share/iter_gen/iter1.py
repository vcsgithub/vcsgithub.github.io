class stepnumbers:
        def __init__(self, iStart=0,  iStep=1,  iEnd=5):
                print( "..creating obj..")
                self.iStart = iStart;    self.iStep = iStep;     self.iEnd = iEnd

        def __iter__(self):
                print( "..iterating..")
                return self 

        def __next__(self):
                print( "...within next ", end = ':')
                iNext = self.iStart + self.iStep
                if iNext > self.iEnd:
                        print( "the end");          raise StopIteration()
                self.iStart = iNext
                return iNext

o = stepnumbers(2,2,10)
print( "...cp1...", type(o))

for i in o:
        print( "num",i)


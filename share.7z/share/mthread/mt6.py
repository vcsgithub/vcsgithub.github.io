print("dbg-2")
import threading
print("dbg-1")
import time

print("dbg0")
class myThread (threading.Thread):

      def __init__(self, threadID, tname, tdelay):
        	threading.Thread.__init__(self)
        	self.threadID = threadID
        	self.tname = tname
        	self.tdelay = tdelay

      def run(self):
            print ("Starting " + self.tname)
    	        
            # Get lock to synchronize threads
            threadLock.acquire()
            print_time(self.name, self.tdelay, 2)
    	        
            # Free lock to release next thread
            threadLock.release()
            print ("Exiting " + self.tname)


def print_time(threadName, tdelay, counter):
    while counter:
        time.sleep(tdelay)
        print ("%s: %s" % (threadName, time.ctime(time.time())))
        counter -= 1

print("dbg1")
threadLock = threading.Lock()
threads = []
print("dbg2")
# Create new threads
thread1 = myThread(1, "Thread-1", 1)
thread2 = myThread(2, "Thread-2", 2)
# Start new Threads
thread1.start()
thread2.start()

# Add threads to thread list
threads.append(thread1)
threads.append(thread2)

# Wait for all threads to complete
for t in threads:
    t.join()
print( "Exiting Main Thread")

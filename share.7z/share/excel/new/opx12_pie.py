# Pie Chart

import openpyxl

book = openpyxl.Workbook()
sheet = book.active

rows = [
    ("Asian Paints", 2125),
    ("HDFC", 1652),
    ("Infosys", 1985),
    ("Maruti", 4522),
    ("ONGC", 2160),
    ("Vedanta", 2270)
]

for row in rows:
    sheet.append(row)

####

data1 = openpyxl.chart.Reference(sheet, min_col=2, min_row=1, max_col=2, max_row=6)
categs = openpyxl.chart.Reference(sheet, min_col=1, min_row=1, max_col = 1,max_row=6)

chart = openpyxl.chart.PieChart()
chart.add_data(data1)
chart.set_categories(categs)

chart.varyColors = True
chart.title = "Nifty Stocks"

sheet.add_chart(chart, "F3")    

book.save("pie_chart.xlsx")
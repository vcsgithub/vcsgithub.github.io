import shelve 
r = shelve.open("myshelf.dat") 
print r["skill"] 
print r["age"] 
print r["name"] 
r.close()
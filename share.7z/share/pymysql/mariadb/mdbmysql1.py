"""
Four Stages of Database Communication
    1.	Create a connection object.
    2.	Create a cursor object to read/write, traverse the records in a Table.
    3.	Interact with the database.
    4.	Close the connection.
"""

import pymysql

connector = pymysql.connect(host='192.168.1.4', port=3306, user='root', passwd='')
print(connector)

# prepare a cursor object using cursor() method
sql_cursor = connector.cursor()
print(sql_cursor)

# execute SQL query using execute() method.
sql_cursor.execute("SELECT VERSION()")

# Fetch a single row using fetchone() method.
data1 = sql_cursor.fetchone()
print ("Database version : %s " % data1)

connector.close()           # disconnect from server
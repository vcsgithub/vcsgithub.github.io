class Point(object):
        x = 3;      y = -3  

class Rectangle(object):
        breadth = 20;       height =10
        centre = Point()

def findTopRight(box):
        tr = Point()      # tr is top right point.
        tr.x = box.centre.x + box.breadth/2.0
        tr.y = box.centre.y + box.height/2.0
        return tr

r1 = Rectangle()
trp = findTopRight(r1)     # if outside the class as an independent function  
#trp = r1.findTopRight()      #if inside the class as a internal method
print(trp.x, trp.y)

# given a equilateral triangle, with base = 20 units
# midpoint of base is at (0,0), find all three corners of triangle.
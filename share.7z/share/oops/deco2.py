
def greet(name):
        return "Hello "+name

greet_someone = greet
print(type(greet_someone))
mystr = greet_someone("Mysore")
print(mystr);print()

greet_someone = greet("Mumbai")
print(type(greet_someone))
print(greet_someone)


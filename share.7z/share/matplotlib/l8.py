
import matplotlib.pyplot as plt

x1 = [2,4,6,8,10]
y1 = [1,3,5,7,9]

plt.plot(x1,y1,':bo')		#blue circle
plt.xticks([1,4,7,10,13])
#plt.xticks(range(10))
plt.yticks([1,3,5,7,9])
plt.show()





import tkinter as tk

window = tk.Tk()
window.configure(background="#f0f0f0")
window.title("Welcome")
window.geometry("300x300")
window.iconbitmap("c:/Users/vinay/python/tkgui/favicon.ico")

photo = tk.PhotoImage(file="cube.gif")
windowimagelabel = tk.Label(window, image=photo)
windowimagelabel.pack()

def tkquit():
    window.destroy()

def do_ping(domain):
    #uEntry.delete(0, tk.END)
    import os
    os.system('ping' + '  ' + domain)
    print("ping1 ", domain)
    print("ping2 ", domain)
    print("Closing the Window")
    tkquit()


def callback():
    print("Ping Started")
    hostid = uEntry.get()
    print(hostid)
    do_ping(hostid)


ulabel = tk.Label(window, text="Enter HostID")
ulabel.pack()

uEntry = tk.Entry(window)
uEntry.pack()

button = tk.Button(window, text="PingNow", command=callback)
button.pack()

window.mainloop()

def greet(name):
        return "Hello " + name 

def call_func(func):
        print("test 2")
        other_name = "Python"
        return func(other_name)  

print("test 1")
mystr = call_func(greet)
print("test 3")
print(mystr)


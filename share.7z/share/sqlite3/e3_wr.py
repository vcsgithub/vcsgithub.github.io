import   sqlite3    as sql

conn = sql.connect("players3.db")

with conn:
        curs = conn.cursor()    
        curs.execute("DROP TABLE IF EXISTS Playerstb3")
        curs.execute("CREATE TABLE Playerstb3(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR(25), Age         INT, Game     TEXT)")
        curs.execute("INSERT INTO Playerstb3(Name,Age,Game) VALUES('Rahul',45,'Cricket')")
        curs.execute("INSERT INTO Playerstb3(Name,Game) VALUES('Sunil','Soccer')")
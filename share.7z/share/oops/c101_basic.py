class MyEmployee():
    e =  "Engineer"
    a =  "Admin"
    m = "Manager"
    
    getE = lambda self : self.e
    getA = lambda self : self.a

employee1 = MyEmployee() 
print(employee1.e);  print(employee1.getE())
employee1.a = "Accountant"       
print(employee1.getA())

employee2 = MyEmployee() 
print(employee2.getA())                # did u get Accountant ?????

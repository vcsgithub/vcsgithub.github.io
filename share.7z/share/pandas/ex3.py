# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 12:48:22 2017

@author: vinay
"""

#import pandas as pd
import datetime
import pandas as pd
#import pandas.io.data as web
from pandas_datareader import data as web
from nsepy  import get_history, get_index_pe_history 

start = datetime.datetime(2016, 1, 1)
end = datetime.datetime(2017, 7,24)
#end = datetime.date.today()

google = web.DataReader("GOOGL", "google", start, end)
print(type(google))

amazon = web.DataReader("AMZN", "google", start, end)
print(type(amazon))
facebook = web.DataReader("FB", "google", start, end)
print(type(facebook))
print(google.head())
print(amazon.head())

hdfc = get_history("HDFC",start, end)
sunp = get_history("SUNPHARMA",start, end)

#print(sbin.head())

df = pd.DataFrame({"GOOG": google["Close"],
                      "AMZN": amazon["Close"],
                      "HDFC": hdfc["Close"],
                      "SUNPHARMA": sunp["Close"],
                      "FB": facebook["Close"]})
#df = web.DataReader("BHARTIARTL.NS", "yahoo", start, end)
print(df)
print(df.head())

df.plot(grid = True)

import matplotlib.pyplot as plt
from matplotlib import style

style.use('fivethirtyeight')

#df.plot()
plt.legend()
plt.show()

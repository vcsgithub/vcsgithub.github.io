# -*- coding: utf-8 -*-
"""
Created on Tue May 30 19:03:57 2017

@author: vinay
"""

import matplotlib
import matplotlib.pyplot as plt

x1 = [2,4,6,8,10]
y1 = [1,3,5,7,9]

x2 = [12,14,16,18,20]
y2 = [11,13,15,17,19]

plt.plot(x1,y1,color='r',label="plot1", linewidth=1,linestyle='--',marker='o')
plt.plot(x2,y2,color='b',label="plot2",linewidth=2, linestyle='-',marker='s')
matplotlib.rcParams['legend.edgecolor']='b'
matplotlib.rcParams['font.family']='Arial'
plt.legend(loc=4,fontsize=18)
plt.show()


#Location String/Code
#'best'/0,           'upper right'/1,    'upper left'/2,     'lower left'/3
#'lower right'/4,    'right'/5,          'center left'/6,    'center right'/7
#'lower center'/8,   'upper center'/9,   'center'/10
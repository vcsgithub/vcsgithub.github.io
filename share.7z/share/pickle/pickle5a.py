import pickle

class Animal:
        def __init__(self):
               print("Animal created")
               print "ClassnameA",self.__class__.__name__

        def whoAmI(self):
               print("Animal")

        def eat(self):
                print("Eating")

file_Name = "pick5"

fileObjectr = open(file_Name,'rb')    # we open the file for reading
myobj = pickle.load(fileObjectr)    # load the object from the file into a variable 

print(myobj); print(type(myobj))
myobj.eat()
fileObjectr.close()   

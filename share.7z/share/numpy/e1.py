#create a array using a list

import numpy as np

print(np.__version__,"\n")

list1 = [[11,21,31],[41,51,61], [71,81,91],[101,111,121]]

print(list1)
print(len(list1), type(list1))
print('\n')

arr1 = np.array(list1, dtype=np.int64)
print(arr1)
print('\n')
print(type(arr1))
print(arr1.shape)
print(arr1.ndim)
print(arr1[0,0])
print(type(arr1[0,0]))
print(arr1.strides)

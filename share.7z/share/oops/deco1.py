def identity_decorator(target_function):
        def wrapper():
                print("calling through decorator")
                target_function()       # wraps the target within a wrapper
                print("called through decorator")
        return wrapper

def a_function():
        print("Normal function.")
def b_function():
        print("Normal function.")

aplus_function = identity_decorator(a_function)

a_function()
aplus_function()

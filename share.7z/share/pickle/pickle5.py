import pickle

class Animal:
        def __init__(self):
               print("Animal created")
               print "ClassnameA",self.__class__.__name__

        def whoAmI(self):
               print("Animal")

        def eat(self):
                print("Eating")

an = Animal()
an.eat()

file_Name = "pick5"
fileObjectw = open(file_Name,'wb') 
pickle.dump(an,fileObjectw)   # this writes the object rawdata to the file
fileObjectw.close()                        # here we close the fileObject

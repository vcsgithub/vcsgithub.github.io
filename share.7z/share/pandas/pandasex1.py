
import datetime
#import pandas.io.data as web
from pandas_datareader import data as web
import matplotlib.pyplot as plt
from matplotlib import style

start = datetime.datetime(2016, 1, 1)
end = datetime.datetime(2017, 7, 23)

df = web.DataReader("GOOGL", "google", start, end)
print(df)
print(df.head())

style.use('fivethirtyeight')

df['High'].plot()
plt.legend()
plt.show()

df1 = df['High'] - df['Low']
print(df1.head())
df1.plot()
plt.show()
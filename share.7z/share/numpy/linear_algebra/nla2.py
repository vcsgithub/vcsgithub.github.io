# Linear Algebra
#dot product of 2 matrices
import numpy as np

a = np.array([[1,2],[3,4]])
b = np.array([[11,12],[13,14]])
print(a);    print('\n')
print(b);    print('\n')

print(np.matmul(a,b));  
print('\n')


a=np.array([[2,5],[4,9]])
b=np.array([3,7])
print(a);    print('\n')
print(b);    print('\n')

print(np.matmul(a,b));  
print('\n')
print(np.matmul(b,a));  
print('\n')

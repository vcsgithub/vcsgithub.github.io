# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 17:15:48 2017

@author: vinay
"""

import pandas as pd
from pandas_datareader  import data as web
import datetime
import nsepy

from nsepy.archive import get_price_history_csv
import   sqlite3    as sql

conn = sql.connect("players3.db")

with conn:
        curs = conn.cursor()   
        curs.execute("SELECT * FROM Playerstb3")

        rows = curs.fetchall()
        for row in rows:
                print(row)

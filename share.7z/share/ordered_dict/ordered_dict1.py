from __future__ import print_function
#An OrderedDict is a dictionary subclass that remembers the order in 
#which its contents are added.

colours1 =  {"Red" : 198, "Green" : 170, "Blue" : 160}
for key, value in colours1.items():
    print(key, value)

print()

import collections
list1 = [("Green1", 198), ("Red1", 150), ("Blue1", 160)]
colours2 = collections.OrderedDict(list1)
for key, value in colours2.items():
    print(key, value)
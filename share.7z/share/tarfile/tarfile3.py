import tarfile

t = tarfile.open('tardir.tar', 'r')
for filename in [ 'README.txt', 'notthere.txt', 'summary.txt' ]:
    try:
        f = t.extractfile('tardir/'+filename)
    except KeyError:
        print 'ERROR: Did not find %s in tar archive' % filename
    else:
        print filename, ':', f.read()
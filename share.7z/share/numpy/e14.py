# Boolean Array Indexing

import numpy as np

def create_np_array(r = 3, c = 4, d = 2):
    x = np.random.randint(25,size=(d,r,c))
    return x


x = np.array([[ 0, 1, 2],[ 3, 4, 5],[ 6, 7, 8],[ 9, 5, 11]])
print (x)
print ('\n')

z = create_np_array(4,5,3)
print(z)
print('\n')

print ('Odd numbers are:')
print (z[z%2 !=0])
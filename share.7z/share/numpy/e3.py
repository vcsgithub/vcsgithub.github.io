#array reshaping

import numpy as np

arr = np.array([[11,21,31],[12,22,32],[13,23,33],[14,24,34]])
print(arr)
print(arr.shape)
print('\n')

b = arr.reshape(3,4)
print(b)
print('\n')

b = b.reshape(2,6)
print(b)
print('\n')

b = b.reshape(2,3,2)
print(b)



#An OrderedDict is a dictionary subclass that remembers the order in which its contents are added.
colours =  {"Red" : 198, "Green" : 170, "Blue" : 160}
for key, value in colours.items():
    print(key, value)

print
from collections import OrderedDict

list1 = [("Green1", 198), ("Red1", 150), ("Blue1", 160)]
colours = OrderedDict(list1)
for key, value in colours.items():
    print(key, value)
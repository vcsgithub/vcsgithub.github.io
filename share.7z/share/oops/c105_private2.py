class JustCounter(object):
        __secretCount = 0
      
        def count(self):
                self.__secretCount += 1
                print(self.__secretCount)
                self.__modname()

        def __modname(self):
                print("__name__ = %s:%d " %(__name__, self.__secretCount))

counter = JustCounter()
counter.count();    counter.count()
counter.__modname()




##object._className__attrName

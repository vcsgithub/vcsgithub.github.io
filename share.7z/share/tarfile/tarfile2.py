import tarfile
import time

t = tarfile.open('tardir.tar', 'r')
print t.getnames()

#t = tarfile.open('tardir.tar', 'r')
for member_info in t.getmembers():
    print member_info.name
    print '\tModified:\t', time.ctime(member_info.mtime)
    print '\tMode    :\t', oct(member_info.mode)
    print '\tSize    :\t', member_info.size, 'bytes'
    print
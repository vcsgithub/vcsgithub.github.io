import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df=pd.DataFrame(np.random.rand(10,4),columns=['a','b','c','d'])
print(df)
df.plot.bar(stacked=True)


plt.show()

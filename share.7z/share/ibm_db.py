import ibm_db as ibm


class SQLClass():
    def checkVersion():
        # Open database connection
        connector = ibm.connect("DATABASE=MY_DB2;HOSTNAME=19.128.263.338;PORT=270;PROTOCOL=TCPIP;UID=username;PWD=password;", "", "")
        print(connector)
        # prepare a cursor object using cursor() method
        stmt = ibm.exec_immediate(connector,"SELECT * FROM MY_DB2")
        result = ibm.fetch_both(stmt)
        if (result):
            print("Result from database is : ", result)

SQLClass.checkVersion()

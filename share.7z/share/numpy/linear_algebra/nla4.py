# Linear Algebra
# solving linear equations  inverse of a matrix

"""
    x   +  y  + z   = 6
           2y  + 5z = -4
    2x + 5y  -  z  = 27

    1  1  1     x              6
    0  2  5     y      =     -4
    2  5 -1     z             27

        A         X   =  B
"""

import numpy as np

A = np.array([[1,1,1],[0,2,5],[2,5,-1]])
print(A)
print('\n')

B = np.array([[6],[-4],[27]])
print(B)
print('\n')

X = np.linalg.solve(A,B)
print (X)
print('\n')


######### Manual Steps
Ainv = np.linalg.inv(A)
print(Ainv)
print('\n')

X = np.dot(Ainv,B)
print(X)

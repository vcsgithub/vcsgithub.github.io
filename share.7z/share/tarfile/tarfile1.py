# create a tar file thru linux.  tar -cvf filename.tar directory/

import tarfile

result = tarfile.is_tarfile("tardir.tar")
print(result)

result = tarfile.is_tarfile("badtar.tar")
print(result)


for filename in ['tardir.tar', 'badtar.tar', 'nofile.tar' ]:
    try:
        print('%20s  %s' % (filename, tarfile.is_tarfile(filename)))
    except IOError, err:
        print('%20s  %s' % (filename, err))
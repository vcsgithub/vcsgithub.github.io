# Array Slicing

import numpy as np

a = np.array([[1,2,3],[4,5,6],[7,8,9]])
print(a); print('\n')

print( a[1:]); print('\n')   # from row 1 till end row, all cols

print(a[...,1]); print('\n')     # from all rows, but col1

print(a[1,...]); print('\n')     # from row 1, but all cols

print(a[...,1:]); print('\n')    # from all rows, from col1 till end col

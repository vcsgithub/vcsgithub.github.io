# -*- coding: utf-8 -*-
"""
Created on Tue May 30 19:03:57 2017

@author: vinay
"""

import matplotlib.pyplot as plt

x1 = [2,4,6,8,10]
y1 = [1,3,5,7,9]

plt.axis([0,20,0,40])
plt.plot(x1,y1,':bo')		#blue circle
plt.show()

#plt.plot(x1,y1,':rs')		#blue circle
#plt.xlim(0,40)
#plt.ylim(0,20)
#plt.show()




#Loading an already existing excel file in Python and saving a copy of it:

import openpyxl

mywb = openpyxl.load_workbook('filetest.xlsx')

sheet = mywb.active

sheet.title = 'Working on Save as'

mywb.save('example_filetest.xlsx')
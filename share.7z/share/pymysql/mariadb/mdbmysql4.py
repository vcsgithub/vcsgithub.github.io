import pymysql as pms

connector = pms.connect(host='192.168.1.4', port=3306, user='root', passwd='', db='mysql')

with connector:
    
    sql_cursor = connector.cursor()
    sql_cursor.execute("SELECT * FROM Players2")

    rows = sql_cursor.fetchall()

    for row in rows:
        print(row)


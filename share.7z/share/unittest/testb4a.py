import unittest

class MyTest(unittest.TestCase):

    def setUp(self):
        print("setup")
        self.a=10;        self.b=20

    def tearDown(self):
        print("teardown")
        print self.result

    def testTrue(self):
        self.result = (self.a + self.b) >= 30
        self.assertTrue(self.result)

    def testFalse(self):
        self.result = (self.a + self.b) > 30
        self.assertFalse(self.result)

    def testEqual(self):
        self.result = self.a + self.b
        self.assertEqual(self.result,30)

    def testNotEqual(self):
        self.result = self.a + self.b
        self.assertNotEqual(self.result,31)

if __name__ == '__main__':
    unittest.main()
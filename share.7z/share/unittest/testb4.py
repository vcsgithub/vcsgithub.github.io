import unittest

class MyTest(unittest.TestCase):

    def testTrue(self):
        a = 10;         b = 20
        
        result = (a + b) >= 30
        self.assertTrue(result)

        print result

    def testFalse(self):
        a = 10;         b = 20
        
        result = (a + b) > 30
        self.assertFalse(result)

        print result

    def testEqual(self):
        a = 10;         b = 20

        result = a + b
        self.assertEqual(result,30)

        print result

    def testNotEqual(self):
        a = 10;         b = 20

        result = a + b
        self.assertNotEqual(result,31)

        print result

#if __name__ == '__main__':
#    unittest.main()
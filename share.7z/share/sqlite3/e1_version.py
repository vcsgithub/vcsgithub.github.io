"""
Four Stages of Database Communication
    1.	Create a connection object.
    2.	Create a cursor object to read/write, traverse the records in a Table.
    3.	Interact with the database.
    4.	Close the connection.
"""
import   sqlite3    as sql

sqlconn = sql.connect("demo.db")
print(sqlconn);    print(type(sqlconn))

sqlcursor = sqlconn.cursor()
print(sqlcursor); print(type(sqlcursor))

sqlcursor.execute("SELECT SQLITE_VERSION()")
data1 = sqlcursor.fetchone()   # Fetch a single row using fetchone() method.
print ("Database version : %s " % data1)

sqlconn.close()           # disconnect from server


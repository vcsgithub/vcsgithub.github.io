import matplotlib.pyplot as plt
import random

y = []
for i in range(20):
    y = y + random.sample(range(10), 5)

print(y)
print(len(y))

for m in range(10):
    n = y.count(m)
    print("%d appears %d times" % (m, n))

plt.xlabel("Value")
plt.ylabel("Frequency")

plt.hist(y, color='red', rwidth=0.9)
plt.show()

bins = 5
plt.hist(y,bins,rwidth=0.75)
plt.show()


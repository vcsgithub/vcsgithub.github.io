# double-ended queue, or deque
import collections

d = collections.deque('abcdefg')
print 'Deque:', d
print type(d)
print 'Length:', len(d)
print 'Left end:', d[0]
print 'Right end:', d[-1]

print "Remove"
d.remove('c')
print 'remove(c):', d

print "Add Right"
# Add to the right
d = collections.deque()
d.extend('abcdefg')
print 'extend    :', d
d.append('h')
print 'append    :', d

print "Add Left"
# Add to the left
d = collections.deque()
d.extendleft('abcdefg')
print 'extendleft:', d
d.appendleft('h')
print 'appendleft:', d

print "Consume from Right"
print d.pop()
print 'pop:', d
print "Consume from Left"
print d.popleft()
print 'popleft:', d

d.rotate(2)
print 'Right rotation:', d

d.rotate(-2)
print 'Left rotation :', d
import shelve 

r = shelve.open("myshelf.dat") 
for key in r:
   print(key,r[key] )

r.close()
import pymysql as pms

connector = pms.connect(host='192.168.1.4', port=3306, user='root', passwd='', db='mysql')

with connector:
        sql_cursor = connector.cursor()
        sql_cursor.execute("show tables")
        rows = sql_cursor.fetchall()
        print(type(rows))
for row in rows:
        print(row)

if  ('players2',) in rows:
        sql_cursor.execute("DROP TABLE IF EXISTS Players2")

if  ('players1',) in rows:
        sql_cursor.execute("DROP TABLE IF EXISTS Players1")

if  ('players',) in rows:
        sql_cursor.execute("DROP TABLE IF EXISTS Players")


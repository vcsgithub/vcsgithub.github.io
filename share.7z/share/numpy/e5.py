# Standard Array Creation Routines

import numpy as np

nr = np.random.random((2,2))
print (nr)
print('\n')

ni = np.identity((3))
print (ni)
print('\n')

ne = np.eye(4, k= 1)
print (ne)
print('\n')
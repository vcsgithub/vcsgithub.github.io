def decorator(target_fn):
        print("decorator")
        def wrapper(stepsize):
                print((target_fn.__name__), end = ', ')
                wrapper.count += stepsize
                print("wc", wrapper.count, end = ' : ')
                target_fn(wrapper.count)
        wrapper.count = 4
        return wrapper

def a_fn(param1):
        print("*",param1 * 2)

a_fn = decorator(a_fn)

print("Start")
a_fn(2)
a_fn(3)  


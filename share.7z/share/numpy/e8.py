# Array Indexing

import numpy as np

x = np.array([[1, 2], [3, 4], [5, 6]])
print(x)
print('\n')
y = x[[0,1,2], [0,1,0]]
print(y)
print('\n')

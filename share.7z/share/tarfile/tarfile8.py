import tarfile

import time

t = tarfile.open('tarfile_compression.tar.gz', 'r:gz')
for member_info in t.getmembers():
    print member_info.name
    print '\tModified:\t', time.ctime(member_info.mtime)
    print '\tMode    :\t', oct(member_info.mode)
    print '\tSize    :\t', member_info.size, 'bytes'
    print

t.extractall('gzdir')
t.close()
#creating a Workbook/Worksheet.

import openpyxl as xl

book = xl.Workbook()
sheet = book.active

sheet['A1'] = 56
sheet['A2'] = 43
sheet['A3'] = 'HelloWorld'
sheet.cell(row=2, column = 5).value = "Hello"   # indexing in the sheet starts from 1. E2.

book.save("sample1.xlsx")

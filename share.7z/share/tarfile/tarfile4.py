import tarfile
import os

os.mkdir('outdir')
t = tarfile.open('tardir.tar', 'r')
t.extractall('outdir')
#print os.listdir('outdir')


for root, dirs, files in os.walk("./outdir"):
    print(os.getcwd())
    print(root)
    print(dirs)
    print(files)
    print
    for name in files:
        print(os.path.join(root, name))
    print
    for name in dirs:
        print(os.path.join(root, name))
import json

data = {}  
print(type(data),data)
data['people'] = []  
print(type(data),data)
data['people'].append({  
    'name': 'Scott',
    'website': 'stackabuse.com',
    'from': 'Nebraska'
})
print(type(data),data, type(data['people']))
data['people'].append({  
    'name': 'Larry',
    'website': 'google.com',
    'from': 'Michigan'
})
print(type(data),data, type(data['people']))
data['people'].append({  
    'name': 'Tim',
    'website': 'apple.com',
    'from': 'Alabama'
})
print(type(data),data, type(data['people']))

with open('data.txt', 'w') as outfile:  
    json.dump(data, outfile)



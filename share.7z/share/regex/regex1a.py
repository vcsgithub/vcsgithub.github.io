import re

def re_example1():
        mystr = "IndexPrice@NSExchange@10k@15102k17"
        mobj = re.search(r"\d\dk",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d\d\dk",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d{4}k",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d{3,9}k",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d{5,9}k",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d{6,9}k",mystr)
        if (mobj):      print(mobj);

#re_example1()

def re_example2():
        mobj = re.search(r"..","ab\tc\nvwxyz")
        if (mobj):      print(mobj);
        mobj = re.search(r"...","ab\tc\nvwxyz")
        if (mobj):      print(mobj);
        mobj = re.search(r"....","ab\tc\nvwxyz")
        if (mobj):      print(mobj);
        mobj = re.search(r".....","ab\tc\nvwxyz")
        if (mobj):      print(mobj);

#re_example2()

def re_example3():
        print(re.search(r"ar+","Lion roarrs Grrrurrrre"))
        print(re.search(r"r+s","Lion roarrs Grrrurrrre"))
        print(re.search(r"gr+","Lion roarrs Grrrurrrre", re.I))
        print(re.search(r"or*","Lion roarrs Grrrurrrre"))
        print(re.search(r"r*e","Lion roarrs Grrrurrrre"))
        print(re.search(r"a{3}r+u","Lion aaaarrrrr roaarrrru aaarrrurrrre"))
        print(re.search(r"r+u*r*e*","Lion roarrs Grrrurrrre"))
        print(re.search(r"r+u*r+e*","Lion roarrs Grrrurrrre"))

#re_example3()

def re_example4():
        mystr = "Stock_456Value  123@NSEM.com is High"

        pattern = r"\s\d\d\d"
        print(re.search(pattern, mystr))

        pattern = r"\s+is\s+"
        print(re.search(pattern, mystr))

#re_example4()

def re_example5():
        print(re.search(r"^r\w+","KingSing",re.I))
        print(re.search(r"^r\w+","RingSing",re.I))

        print(re.search(r"\w+g$","King Sing",re.I))
        print(re.search(r"^r\w+g$","RingSing",re.I))

        print(re.search(r"^rg$","RingSing",re.I))
        print(re.search(r"^rg$","Rg",re.I))

        print(re.search(r"^$",''))

#re_example5()

def re_example6():
        mystr = 'apple alice.wonder@gmail.com mango tom-jerry@in.yahoo.com orange'
        emails = re.findall(r'[\w.-]+@[\w.-]+', mystr)
        print(emails)
#re_example6()

def re_example7():
        mystr = "99@IndexPrice@NSE91change"
        mobj = re.search(r"[a-z]+|$",mystr,re.I)
        if (mobj):      print(mobj);
        mobj = re.search(r"\d+|@",mystr)
        if (mobj):      print(mobj);
        mobj = re.search(r"[^\d@]+",mystr)
        if (mobj):      print(mobj);



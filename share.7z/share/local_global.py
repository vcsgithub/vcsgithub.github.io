num1 = 100; num2 = 200

def local_check():
        num3 = 444

        num1 = 130;	num2 = 240
        print("dbg 2:",num1,num2,num3)
        print(locals())

print("dbg 1:",num1,num2)
local_check()
print("dbg 3:",num1,num2)
print(num3)		#not in global namespace
print(globals())
print(type(local_check))

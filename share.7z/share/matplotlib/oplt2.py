# -*- coding: utf-8 -*-
"""
Created on Mon Jun  5 20:49:51 2017

@author: vinay
"""

import matplotlib.pyplot as plt

x = [2, 4, 6, 8, 10, 12, 14]
y = [1, 3, 5, 7, 9, 11, 13]

#plt.plot(x, y)
plt.plot(x, y, c='r', marker='o')
#plt.draw()
#plt.plot(x, y, 'k', '--')     # bgr cmy kw
#plt.plot(x,y,'b*')
#plt.plot(x,y,'r--')
plt.grid()
plt.show()



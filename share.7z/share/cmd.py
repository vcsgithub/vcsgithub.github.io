#!/usr/bin/python3

import sys

print( "Arg Count: ", len(sys.argv))
print( "Arg list: ", sys.argv, type(sys.argv))

cmdlen = len(sys.argv)
print(cmdlen)

for item in sys.argv:
    print( item, type(item))

print(sys.argv[0])






def myfunction(**kwargs):
        print(kwargs,   type(kwargs), len(kwargs))

        for item in kwargs:
                print(item,kwargs[item])

        print(kwargs['param1'])

print()
myfunction(param1="hello", param2 = 88)
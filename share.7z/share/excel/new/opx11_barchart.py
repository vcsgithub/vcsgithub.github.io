import openpyxl

book = openpyxl.Workbook();             print(type(book.active))
sheet = book.active

rows = [
    ("Asian Paints", 1125),          ("HDFC", 1652),     ("Infosys", 1100),
    ("Maruti", 5000),                   ("ONGC", 1600),      ("Vedanta", -2217) ]

for row in rows:
    sheet.append(row)

data1 = openpyxl.chart.Reference(sheet, min_col=2, min_row=1, max_col=2, max_row=6)
categs = openpyxl.chart.Reference(sheet, min_col=1, min_row=1, max_col =1,max_row=6)

chart = openpyxl.chart.BarChart()
chart.add_data(data1);         chart.set_categories(categs)

chart.varyColors = True
chart.title = "Nifty Stocks"

sheet.add_chart(chart, "F8")    
book.save("bar_chart1.xlsx")
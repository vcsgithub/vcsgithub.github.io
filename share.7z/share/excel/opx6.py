# Reading multiple  Cells

import openpyxl

mywb = openpyxl.load_workbook("sample1.xlsx")
sheet = mywb.active

cells = sheet['A1': 'B6']

for c1, c2 in cells:
    print("{0:19} {1:10}".format(c1.value, c2.value))

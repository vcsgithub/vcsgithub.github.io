import json

with open('data.txt') as json_file:  
    data = json.load(json_file)
    print(data,type(data))
    for p in data['people']:
        print(type(p))
        print('Name: ' + p['name'])
        print('Website: ' + p['website'])
        print('From: ' + p['from'])
        print('')
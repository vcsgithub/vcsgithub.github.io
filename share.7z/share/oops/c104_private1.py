class JustCounter(object):
        __secretCount = 0
      
        def count(self):
                self.__secretCount += 1
                print(self.__secretCount)

        getSecretCount = lambda self : self.__secretCount

counter = JustCounter()
counter.count();    counter.count()

print(counter.getSecretCount())
print(counter.__secretCount)      # ????


##object._className__attrName
#The standard dictionary includes the method setdefault() for retrieving a value 
#and establishing a default if the value does not exist. 
#By contrast, defaultdict lets the caller specify the default up 
#front when the container is initialized.

import collections

rewards = collections.defaultdict(int)   # int will return a 0
rewards['Sarah Miller'] = 10
print rewards
rewards['Bill James']
print rewards
################

def default_factory():
    return 'DEFVAL'

d = collections.defaultdict(default_factory, key1=29,key2='vol')
print 'd:', d
print  d['key1']
print  d['key2']
print  d['key3']



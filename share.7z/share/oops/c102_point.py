class Point(object):
    x = 0;     y = 0

class Rectangle(object):
    breadth = 20;    height =10
    centre  = Point()       # centre point of a rectangle

r1 = Rectangle()
print (r1.breadth, r1.height, r1.centre.x, r1.centre.y)




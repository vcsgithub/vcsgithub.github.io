
def compose_greet_func():
        def get_message(name):
                print("test 3")
                return "Hello there! " + name

        print("test 4")
        return get_message

print("test 5")
greet = compose_greet_func()
print("test 6")
mystr = greet("Python")
print(mystr)


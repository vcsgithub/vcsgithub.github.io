import pickle

rawdata = ('Indigo','Spice','Jet')
print(rawdata); print(type(rawdata))

file_Name = "pick2"
fileObject = open(file_Name,'wb') 
pickle.dump(rawdata,fileObject)   # this writes the object rawdata to the file
fileObject.close()                        # here we close the fileObject

fileObject = open(file_Name,'r')    # we open the file for reading
myobj = pickle.load(fileObject)    # load the object from the file into var myobj

print(myobj); print(type(myobj))
print(rawdata==myobj)

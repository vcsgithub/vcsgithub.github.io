import unittest
import sys

import testb0
import testb1
import testb2
import testb3
import testb4
import testb4a

loader = unittest.TestLoader()

suite = loader.loadTestsFromModule(testb0)
suite.addTests(loader.loadTestsFromModule(testb1))
suite.addTests(loader.loadTestsFromModule(testb2))
suite.addTests(loader.loadTestsFromModule(testb3))
suite.addTests(loader.loadTestsFromModule(testb4))
suite.addTests(loader.loadTestsFromModule(testb4a))
print suite, type(suite)
print
runner = unittest.TextTestRunner()
result = runner.run(suite)
print result
# Linear Algebra
#dot product of 2 matrices
import numpy as np

a = np.array([[1,2],[3,4]])
b = np.array([11,12])

print(a);    print('\n')
print(b);    print('\n')

print(np.dot(a,b));  
print('\n')


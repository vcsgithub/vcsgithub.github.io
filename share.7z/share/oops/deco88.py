def decorator(target_fn):
        print("decorator")

        def wrapper(stepsize):
                print((target_fn.__name__), end = ', ')
                wrapper.count += stepsize
                print("wc", wrapper.count, end = ' : ')
                target_fn(wrapper.count)
        wrapper.count = 3
        return wrapper

def a_fn(param1):
        print("$", param1 * 2)

def b_fn(param2):
        print("#", param2 * 4)

a_fn(20)    

new_fn0 = decorator(a_fn)
new_fn1 = decorator(b_fn)

print("Start")
new_fn0(2)  
new_fn1(3)         
new_fn0(4)


# multiple return values from a function

def myFunction(n1,n2):
	s = n1 + n2
	d = n1 - n2
	return s,d

s1,d1 = myFunction(20,10)
print (s1,d1, type(s1))

r1 = myFunction(60,30)
print(r1, type(r1), r1[1])

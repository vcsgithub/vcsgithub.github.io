#create a array using a tuple

import numpy as np

tuple1 = ((12.5,22.5,32.5,42.5),(16.7,26.7,36.7,46.7), (18.6,28.6,38.6,48.6))
tuple1 = ((12,22,32,42),(16,26,36,46), (18,28,38,48))

print(tuple1)
print('\n')

arr1 = np.array(tuple1)
print(arr1)
print('\n')
print(type(arr1))
print(type(arr1[0,0]))

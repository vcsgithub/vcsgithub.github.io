#vertical Bar Chart Plotting

import matplotlib.pyplot as plt

stock_names = ["GOOG", "APPL", "IBM", "INTC", "CSCO"]
stock_value = [1000,800,600,400,200]

x_pos = [x for x in range(len(stock_names))]

plt.bar(x_pos, stock_value, align = "center", color = "r", alpha=0.1)
plt.xticks(x_pos, stock_names)
plt.ylabel("Price")
plt.title("Stock Prices")

plt.show()

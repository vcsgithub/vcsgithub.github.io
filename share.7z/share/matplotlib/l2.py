#Plots styles

import matplotlib.pyplot as plt

x1 = [2,4,6,8,10]
y1 = [1,3,5,7,9]

plt.plot(x1, y1, linestyle="dotted", marker="o", color="red")
plt.show()


"""
Four linestyles     
    "-" or "solid",     '-.'  or  "dashdot"        ':'   or  "dotted"          '--'  or "dashed"

# Markers
'>', '<', 'o', 'D', 'P', '*', 'X', 's', 'v', 'H'

# Colors
 b: blue,  g: green, r: red,   c: cyan, m: magenta,   y: yellow,  k: black,w: white

"""
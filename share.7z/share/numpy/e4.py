# Standard Array Creation Routines

import numpy as np

ne = np.empty((3,2),dtype=np.int16)
print (ne)
print('\n')

n1 = np.ones(  (3,4)  ) 
print(n1)
print('\n')

nz = np.zeros( (2,3,4), dtype=np.int16)
print(nz)
print('\n')

nf = np.full( (2,2), 5)
print (nf)
print('\n')


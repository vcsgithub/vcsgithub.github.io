#!/usr/bin/python3

import pymysql as pms

connector = pms.connect(host='192.168.1.4', port=3306, user='root', passwd='')
sql_cursor = connector.cursor()

sql_cursor.execute("SELECT VERSION()")
data = sql_cursor.fetchone()
print ("Database version : %s " % data)

sql_query = "show databases";
sql_cursor.execute(sql_query)
result = sql_cursor.fetchall()
print(result)

sql_query = "show tables";
sql_cursor.execute(sql_query)
result = sql_cursor.fetchall()
print(result)


connector.close()

#creating a Workbook/Worksheet.

import openpyxl as xl
import time

book = xl.Workbook()
sheet = book.active

sheet['A1'] = 56
sheet['A2'] = 43

now = time.strftime("%x")
sheet['A3'] = now

sheet.cell(row=2, column = 5).value = 55

book.save("sample1.xlsx")

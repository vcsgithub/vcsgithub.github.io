# Numerical Ranges

import numpy as np

arr2 = np.arange(2,20,2)
print(arr2)
print('\n')

arr3 = np.arange(2.1, 5.1, 0.25)
print(arr3)
print('\n')

arr4 = np.arange(2.1, 5.1, 0.25,float)
print(arr4)
print('\n')




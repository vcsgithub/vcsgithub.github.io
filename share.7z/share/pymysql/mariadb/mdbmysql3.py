import pymysql as pms

connector = pms.connect(host='192.168.1.4', port=3306, user='root', passwd='', db='mysql')

with connector:
    
    sql_cursor = connector.cursor()
    sql_cursor.execute("DROP TABLE IF EXISTS Players2")
    sql_cursor.execute("CREATE TABLE Players2(Id INT PRIMARY KEY AUTO_INCREMENT,Name VARCHAR(25))")
    sql_cursor.execute("INSERT INTO Players2(Name) VALUES('Anand')")
    sql_cursor.execute("INSERT INTO Players2(Name) VALUES('Gopi')")
    sql_cursor.execute("INSERT INTO Players2(Name) VALUES('Chetri')")
    sql_cursor.execute("INSERT INTO Players2(Name) VALUES('Hina')")
    sql_cursor.execute("INSERT INTO Players2(Name) VALUES('Sindhu')")
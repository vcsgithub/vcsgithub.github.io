class First(object):
    q = 20
    def __init__(self,x=9,y=8):
        self.p = x
        self.q = y
        print ("First Init")

    def MyMethod1(self):
        print("First Method 1")
    def MyMethod2(self):
        print("First Method 2")

class Second(First):
    def __init__(self,x=9,y=8):
        self.m = x
        self.n = y
        print ("Second Init")
        print(type(Second))
        super().__init__()

    def MyMethod1(self):                       ## overridden method
        print("Second Method 1")
        print(self.q)
        super().MyMethod1()

x = First(10,20);
x.MyMethod1();
print(type(x))
print()
y = Second();
y.MyMethod1();
y.MyMethod2();
print(type(y))
print(type(Second))
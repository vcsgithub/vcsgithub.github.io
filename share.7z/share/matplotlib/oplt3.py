# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 11:42:11 2017

@author: vinay
"""

import numpy as np
import matplotlib.pyplot as plt
#plt.ioff()
for i in range(3):
    plt.plot(np.random.rand(10))
    plt.show()
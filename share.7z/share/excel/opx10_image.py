# Insert Image into a Sheet

from openpyxl import Workbook
from openpyxl.drawing.image import Image

book = Workbook()
sheet = book.active

print(type(Image))
img = Image("saturnmoon0.jpg")
sheet['A1'] = 'This is saturnmoon'

sheet.add_image(img, 'B2')

book.save("sheet_image.xlsx")
# Numerical Ranges

import numpy as np

print(np.linspace(1,50))
print('\n')
print(np.linspace(0,10,10))
print('\n')
print(np.linspace(0,10,10,endpoint=False))
print('\n')


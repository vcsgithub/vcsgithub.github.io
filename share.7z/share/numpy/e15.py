# Array Arithmetic

import numpy as np

###########              1

list1 = [[11,22,33],[44,55,66], [77,88,99]]
arr1 = np.array(list1)
print(arr1)
print('\n')

arr1 += 1
print(arr1)
print('\n')

arr1 *= 2
print(arr1)
print('\n')

import matplotlib.pyplot as plt
import matplotlib.style as stl

x = [2,4,6,8,10]
y = [1,3,5,7,9]

x1 = [12,14,16,18,20]
y1 = [11,13,15,17,19]

print(plt.style.available)
stl.use("bmh")
plt.plot(x,y,linewidth=5,label="line1")
plt.plot(x1,y1,linewidth=5, label="line2")
plt.title('Epic Info')
plt.ylabel('Y axis')
plt.xlabel('X axis')

plt.legend()
#plt.grid(None,'r')
plt.show()

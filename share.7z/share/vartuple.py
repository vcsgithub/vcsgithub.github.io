#!/usr/bin/python2.
#*tuple means "take all additional positional arguments to this function 
#and pack them into this parameter as a tuple."

from __future__ import print_function

def tvar(b,*x):
        print (b,x, type(x), len(x))

        for elem in x:
                #print(elem)
                print(elem,end=',')

#a = [2,3,4];    tvar(a)
#tvar([2,3,4])    
tvar(2,3,4,5,6,7)
tvar(1,2,3)   



